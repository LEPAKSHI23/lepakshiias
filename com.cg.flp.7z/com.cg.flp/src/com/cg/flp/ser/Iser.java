package com.cg.flp.ser;

import java.util.ArrayList;

import com.cg.excep.FlpException;
import com.cg.flp.entity.CustomerEntity;

public interface Iser {
	
	public ArrayList<CustomerEntity> add(CustomerEntity userE) throws FlpException;
	public int delete(int id) throws  FlpException ;
	public ArrayList<CustomerEntity> showall() throws FlpException ;
}
