package com.cg.flp.ser;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.excep.FlpException;
import com.cg.flp.dao.IDao;
import com.cg.flp.entity.CustomerEntity;
@Service
@Transactional
public class Ser {
	
	@Autowired
	private IDao userDAO;
	
	
	public Integer add(CustomerEntity userE) throws FlpException {
		
		return userDAO.add(userE);
	}

	public  int delete(int id) throws FlpException {
		return userDAO.delete(id);
	}

	public ArrayList<CustomerEntity> showall() throws FlpException {
		// TODO Auto-generated method stub
		return userDAO.showall();
	}



	
}
