package com.cg.flp.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.excep.FlpException;
import com.cg.flp.entity.CustomerEntity;
import com.cg.flp.entity.CustomerLogin;
import com.cg.flp.entity.MerchantEntity;

@Repository
public class Dao {
	@PersistenceContext
	private EntityManager entityManager;

	CustomerLogin cl = new CustomerLogin();
	MerchantEntity mer = new MerchantEntity();

	public Integer add(CustomerEntity user) throws FlpException {
		try {
			user.setProduct_Name(mer.getProduct_Name());
			user.setProduct_Description(mer.getProduct_Description());
			user.setProduct_Price(mer.getProduct_Price());
			user.setProduct_Id(mer.getProduct_Id());
			user.setCustomer_emailId(cl.getEmail_Id());
			entityManager.persist(user);
			return 1;
		
			
		} catch (PersistenceException e) {
			throw new FlpException(e.getMessage());
		}
		

	}
	
	
	public ArrayList<CustomerEntity> showall() throws FlpException {
		ArrayList<CustomerEntity> list = new ArrayList<>();
		String jpql = "Select product from wishlist product";
		TypedQuery<CustomerEntity> query = (TypedQuery<CustomerEntity>) entityManager.createQuery(jpql, CustomerEntity.class);
		list = (ArrayList<CustomerEntity>) query.getResultList();
		return list;
	}

	public int delete(int id) throws FlpException {
		try {
			CustomerEntity user = (CustomerEntity) entityManager.find(
					CustomerEntity.class, id);
			entityManager.remove(user);
			return 1;
		} catch (PersistenceException e) {
			throw new FlpException(e.getMessage());
		}
	}
}
