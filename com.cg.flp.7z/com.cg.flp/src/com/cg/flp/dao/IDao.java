package com.cg.flp.dao;

import java.util.ArrayList;

import com.cg.excep.FlpException;
import com.cg.flp.entity.CustomerEntity;
import com.cg.flp.entity.MerchantEntity;

public interface IDao {
	
	
	public int delete(int id) throws  FlpException ;

	public Integer add(CustomerEntity userE)  throws  FlpException;
	public ArrayList<CustomerEntity> showall() throws FlpException ;
}
