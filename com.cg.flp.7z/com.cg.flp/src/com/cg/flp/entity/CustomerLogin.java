package com.cg.flp.entity;

import javax.persistence.Id;
import javax.validation.constraints.NotNull;

public class CustomerLogin {
	@Id
	private String email_Id;
	@NotNull
	private String password;
	@NotNull
	private String name;
	@NotNull
	private Integer phoneNumber;
	@NotNull
	private String address;

	public CustomerLogin() {
		super();
	}

	public CustomerLogin(String email_Id, String password, String name,
			Integer phoneNumber, String address) {
		super();
		this.email_Id = email_Id;
		this.password = password;
		this.name = name;
		this.phoneNumber = phoneNumber;
		this.address = address;
	}

	@Override
	public String toString() {
		return "CustomerLogin [email_Id=" + email_Id + ", password=" + password
				+ ", name=" + name + ", phoneNumber=" + phoneNumber
				+ ", address=" + address + "]";
	}

	public String getEmail_Id() {
		return email_Id;
	}

	public void setEmail_Id(String email_Id) {
		this.email_Id = email_Id;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(Integer phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

}
