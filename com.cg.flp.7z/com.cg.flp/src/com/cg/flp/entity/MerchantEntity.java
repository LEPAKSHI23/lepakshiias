package com.cg.flp.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="merchant_product")
public class MerchantEntity {
	@Id
	private Integer product_Id;	
	@NotNull
	private String product_Name;
	@NotNull
	private String product_Category;
	@NotNull
	private String product_Description;
	@NotNull
	private Double product_Price;	
	private String product_Image;
	@NotNull
	private Integer product_Quantity;
	private String product_Discount;
	private Integer timeForDiscount;
	private Integer numberOfProductSold;
	private Double sellingCost;
	private Double exchangeAmount;

	
	
	public MerchantEntity() {
		super();
		
	}
	public MerchantEntity(Integer product_Id, String product_Name,
			String product_Category, String product_Description,
			Double product_Price, String product_Image,
			Integer product_Quantity, String product_Discount,
			Integer timeForDiscount, Integer numberOfProductSold,
			Double sellingCost, Double exchangeAmount) {
		super();
		this.product_Id = product_Id;
		this.product_Name = product_Name;
		this.product_Category = product_Category;
		this.product_Description = product_Description;
		this.product_Price = product_Price;
		this.product_Image = product_Image;
		this.product_Quantity = product_Quantity;
		this.product_Discount = product_Discount;
		this.timeForDiscount = timeForDiscount;
		this.numberOfProductSold = numberOfProductSold;
		this.sellingCost = sellingCost;
		this.exchangeAmount = exchangeAmount;
	}
	public Integer getProduct_Id() {
		return product_Id;
	}
	public void setProduct_Id(Integer product_Id) {
		this.product_Id = product_Id;
	}
	public String getProduct_Name() {
		return product_Name;
	}
	public void setProduct_Name(String product_Name) {
		this.product_Name = product_Name;
	}
	public String getProduct_Category() {
		return product_Category;
	}
	public void setProduct_Category(String product_Category) {
		this.product_Category = product_Category;
	}
	public String getProduct_Description() {
		return product_Description;
	}
	public void setProduct_Description(String product_Description) {
		this.product_Description = product_Description;
	}
	public Double getProduct_Price() {
		return product_Price;
	}
	public void setProduct_Price(Double product_Price) {
		this.product_Price = product_Price;
	}
	public String getProduct_Image() {
		return product_Image;
	}
	public void setProduct_Image(String product_Image) {
		this.product_Image = product_Image;
	}
	public Integer getProduct_Quantity() {
		return product_Quantity;
	}
	public void setProduct_Quantity(Integer product_Quantity) {
		this.product_Quantity = product_Quantity;
	}
	public String getProduct_Discount() {
		return product_Discount;
	}
	public void setProduct_Discount(String product_Discount) {
		this.product_Discount = product_Discount;
	}
	public Integer getTimeForDiscount() {
		return timeForDiscount;
	}
	public void setTimeForDiscount(Integer timeForDiscount) {
		this.timeForDiscount = timeForDiscount;
	}
	public Integer getNumberOfProductSold() {
		return numberOfProductSold;
	}
	public void setNumberOfProductSold(Integer numberOfProductSold) {
		this.numberOfProductSold = numberOfProductSold;
	}
	public Double getSellingCost() {
		return sellingCost;
	}
	public void setSellingCost(Double sellingCost) {
		this.sellingCost = sellingCost;
	}
	public Double getExchangeAmount() {
		return exchangeAmount;
	}
	public void setExchangeAmount(Double exchangeAmount) {
		this.exchangeAmount = exchangeAmount;
	}
	
}





