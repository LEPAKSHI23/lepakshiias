package com.cg.flp.controller;

import java.util.ArrayList;

import org.jboss.security.auth.spi.Users.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.excep.FlpException;
import com.cg.flp.entity.CustomerEntity;
import com.cg.flp.ser.Ser;

@Controller
public class WishlistController {
	@Autowired
	private Ser userService;
	
	@RequestMapping(value="/register", method=RequestMethod.POST)
	public ModelAndView processForm(  @ModelAttribute("user") User user
			){
		
		try {
			com.cg.flp.entity.CustomerEntity userE=new com.cg.flp.entity.CustomerEntity();
			
			 Integer n=userService.add(userE);
			if(n>0)
			{
			return new ModelAndView("cust_status","message"," product added to wishlist");
			}
			else
			{
			return new ModelAndView("cust_status","message","Unable to add product to wishlist");	
			}
			
	
		} catch (Exception e) {			
			return new ModelAndView("sucess","removed",e.getMessage());
		}		
		
	}
	
	
	
	
	
	
	
	@RequestMapping(value="/display", method=RequestMethod.POST)
	public ModelAndView processForm(  @ModelAttribute("user1") User user
			)
			{
		
		try {
			
	
	ArrayList<CustomerEntity> s=userService.showall();
	if(s != null)
	{
	return new ModelAndView("cust_status","message"," s");
	}
	else
	{
	return new ModelAndView("cust_status","message","Unable to add product to wishlist");	
	}
		}
	
	
	@RequestMapping(value="/deleteuser", method=RequestMethod.GET)
	public ModelAndView delete(@RequestParam(value="userid") Integer userid) {
		try {
			
			int n= userService.delete(userid);
			if(n>0) {
				return new ModelAndView("cust_status","message"," Record Deleted");
			}else {
				return new ModelAndView("cust_status","message","Unable to Delete  Record");
			}
		}catch(FlpException e) {
			return new ModelAndView("sucess","removed",e.getMessage());
		}
	}
 
}
