package com.capgemini.trg.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.trg.model.HelloWorld;

public class Tester {
	public static void main(String[] args) {

		@SuppressWarnings("resource")
		ApplicationContext context = new ClassPathXmlApplicationContext("test.xml");
		
		@SuppressWarnings("unused")
		HelloWorld object1 = (HelloWorld)context.getBean("helloWorldBean");
		/*HelloWorld object2 = (HelloWorld)context.getBean("helloWorldBean");
		System.out.println(object1.hashCode());
		System.out.println(object1);
		System.out.println(object2.hashCode());
		System.out.println(object2);*/
		((AbstractApplicationContext) context).registerShutdownHook();
	}

}
