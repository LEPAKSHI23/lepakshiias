package com.capgemini.trg.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.trg.model.Person;

public class PersonTester {

	public PersonTester() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		@SuppressWarnings("resource")
	
		
		ApplicationContext context = new ClassPathXmlApplicationContext(
				"person2.xml");
		Person person1 = (Person) context.getBean("personBean");
		System.out.println(person1.getAdharnumber());
		System.out.println(person1.getName());
		System.out.println(person1.getResidentialAddress().getHouseNumber());
		System.out.println(person1.getParmanentAddress().getHouseNumber());
		((AbstractApplicationContext) context).registerShutdownHook();

	}
}
