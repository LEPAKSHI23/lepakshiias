package com.capgemini.trg.model;

public interface CurrencyConverter {

public abstract	double dollarToRupee(double dollars);

}
