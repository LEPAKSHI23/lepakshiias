package com.capgemini.BankApplication.Utility;

import javax.persistence.EntityManager;
import javax.persistence.Persistence;

public class JPAUtil {

	
		public static EntityManager getEntityManager() {
			
			EntityManager factory = Persistence.createEntityManagerFactory("BankApplication").createEntityManager();
			return factory;
		}
	}


