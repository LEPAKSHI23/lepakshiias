package com.capgemini.trg.model;

public class HelloWorld {
	private String  message;
	
	public HelloWorld(){
		
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}


	public HelloWorld(String message) {
		super();
		this.message = message;
	}

}
