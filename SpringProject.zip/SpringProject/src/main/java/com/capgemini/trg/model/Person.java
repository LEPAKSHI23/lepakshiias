package com.capgemini.trg.model;

public class Person {

	private Long adharnumber;
	private String name;
	private Address residentialAddress;
	private Address parmanentAddress;

	public Person(Long adharnumber, String name, Address residentialAddress,
			Address parmanentAddress) {
		super();
		this.adharnumber = adharnumber;
		this.name = name;
		this.residentialAddress = residentialAddress;
		this.parmanentAddress = parmanentAddress;
	}

	public Long getAdharnumber() {
		return adharnumber;
	}

	public void setAdharnumber(Long adharnumber) {
		this.adharnumber = adharnumber;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Address getResidentialAddress() {
		return residentialAddress;
	}

	public void setResidentialAddress(Address residentialAddress) {
		this.residentialAddress = residentialAddress;
	}

	public Address getParmanentAddress() {
		return parmanentAddress;
	}

	public void setParmanentAddress(Address parmanentAddress) {
		this.parmanentAddress = parmanentAddress;
	}

	public Person() {
		// TODO Auto-generated constructor stub
	}

}
